package com.reda.note;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.app.PendingIntent;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private static final int REQUEST_POST_NOTIFICATIONS = 401;
    private static final String FOCUS_CHANNEL_ID = FocusAlarmReceiver.CHANNEL_ID;
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setDefaultTextEncodingName("UTF-8");

        webView.addJavascriptInterface(new AppBridge(), "RedaAndroid");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);

        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html");
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    private void ensureFocusNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null && manager.getNotificationChannel(FOCUS_CHANNEL_ID) == null) {
                NotificationChannel channel = new NotificationChannel(
                    FOCUS_CHANNEL_ID,
                    "تنبيهات جلسة التركيز",
                    NotificationManager.IMPORTANCE_HIGH
                );
                channel.setDescription("تنبيه عند انتهاء جلسة التركيز في Reda Note");
                channel.enableVibration(true);
                channel.setVibrationPattern(new long[]{0, 180, 90, 180});
                manager.createNotificationChannel(channel);
            }
        }
    }

    private boolean canPostNotifications() {
        if (Build.VERSION.SDK_INT < 33) return true;
        return checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    private final class AppBridge {
        @JavascriptInterface
        public void requestNotificationPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && !canPostNotifications()) {
                    requestPermissions(
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        REQUEST_POST_NOTIFICATIONS
                    );
                } else {
                    ensureFocusNotificationChannel();
                    notifyWebView("تم تفعيل إشعارات انتهاء جلسة التركيز");
                }
            });
        }

        @JavascriptInterface
        public boolean hasNotificationPermission() {
            return canPostNotifications();
        }

        @JavascriptInterface
        public void scheduleFocusNotification(long delayMs) {
            runOnUiThread(() -> {
                if (!canPostNotifications()) return;
                long delay = Math.max(1000L, Math.min(delayMs, 2L * 60L * 60L * 1000L));
                Intent intent = new Intent(MainActivity.this, FocusAlarmReceiver.class);
                intent.putExtra(FocusAlarmReceiver.EXTRA_TITLE, "انتهت جلسة التركيز");
                intent.putExtra(FocusAlarmReceiver.EXTRA_MESSAGE, "أحسنت! حان وقت استراحة قصيرة.");
                PendingIntent pendingIntent = PendingIntent.getBroadcast(
                    MainActivity.this,
                    2401,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                );
                AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                if (alarmManager != null) {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + delay, pendingIntent);
                }
            });
        }

        @JavascriptInterface
        public void cancelFocusNotification() {
            runOnUiThread(() -> {
                Intent intent = new Intent(MainActivity.this, FocusAlarmReceiver.class);
                PendingIntent pendingIntent = PendingIntent.getBroadcast(
                    MainActivity.this,
                    2401,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                );
                AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                if (alarmManager != null) alarmManager.cancel(pendingIntent);
                pendingIntent.cancel();
            });
        }

        @JavascriptInterface
        public void showFocusNotification(String title, String message) {
            runOnUiThread(() -> {
                if (!canPostNotifications()) {
                    notifyWebView("فعّل إشعارات الهاتف من إعدادات جلسة التركيز");
                    return;
                }
                ensureFocusNotificationChannel();
                NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                if (manager == null) return;

                Notification.Builder builder;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    builder = new Notification.Builder(MainActivity.this, FOCUS_CHANNEL_ID);
                } else {
                    builder = new Notification.Builder(MainActivity.this);
                }
                builder.setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle(title == null || title.isEmpty() ? "Reda Note" : title)
                    .setContentText(message == null ? "انتهت جلسة التركيز." : message)
                    .setAutoCancel(true)
                    .setDefaults(Notification.DEFAULT_ALL);

                manager.notify(2401, builder.build());
            });
        }

        @JavascriptInterface
        public void vibrate(long durationMs) {
            runOnUiThread(() -> {
                try {
                    Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    if (vibrator == null || !vibrator.hasVibrator()) return;
                    long duration = Math.max(80, Math.min(1200, durationMs));
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vibrator.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE));
                    } else {
                        vibrator.vibrate(duration);
                    }
                } catch (Exception ignored) {
                    // Haptics are optional; the in-app completion message still appears.
                }
            });
        }
    }

    private void notifyWebView(String message) {
        if (webView == null) return;
        String safeMessage = message.replace("\\", "\\\\").replace("'", "\\'");
        webView.evaluateJavascript("window.__redaNativeMessage && window.__redaNativeMessage('" + safeMessage + "')", null);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_POST_NOTIFICATIONS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                ensureFocusNotificationChannel();
                notifyWebView("تم تفعيل إشعارات انتهاء جلسة التركيز");
            } else {
                notifyWebView("لم يتم منح صلاحية الإشعارات. سيظهر التنبيه داخل التطبيق فقط.");
            }
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
